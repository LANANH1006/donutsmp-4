package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.literal;

/** Combat tag (/ct), /pvp toggle, vung spawn khong PvP. */
public class Combat {
    static int tagTicks() { return 20 * Admin.inum("combat_seconds"); }

    static final Map<UUID, Long> TAG = new HashMap<>();
    static final Set<UUID> PVP_OFF = new HashSet<>();

    public static boolean tagged(ServerPlayerEntity p) {
        if (!Admin.on("combat")) return false;
        Long t = TAG.get(p.getUuid());
        return t != null && DonutLike.tick < t;
    }

    static boolean inSpawnZone(ServerPlayerEntity p) {
        if (!Admin.on("spawnpvp") || !p.getWorld().getRegistryKey().equals(World.OVERWORLD)) return false;
        double sx, sz;
        if (DonutLike.save.spawn != null) { sx = DonutLike.save.spawn[0]; sz = DonutLike.save.spawn[2]; }
        else { var sp = p.getServer().getOverworld().getSpawnPos(); sx = sp.getX(); sz = sp.getZ(); }
        double dx = p.getX() - sx, dz = p.getZ() - sz;
        double r = Admin.num("spawn_radius");
        return dx * dx + dz * dz <= r * r;
    }

    static void init() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity victim)) return true;
            if (!(source.getAttacker() instanceof ServerPlayerEntity atk) || atk == victim) return true;
            if (Admin.on("pvpcmd") && (PVP_OFF.contains(victim.getUuid()) || PVP_OFF.contains(atk.getUuid())) || inSpawnZone(victim) || inSpawnZone(atk)) {
                DonutLike.msg(atk, "§cPvP đang tắt (vùng spawn hoặc /pvp).");
                return false;
            }
            if (!Admin.on("combat")) return true;
            long until = DonutLike.tick + tagTicks();
            if (!tagged(victim)) DonutLike.msg(victim, "§c[Combat] Bạn đang trong chiến đấu! Thoát game = chết, không dùng được lệnh dịch chuyển.");
            if (!tagged(atk)) DonutLike.msg(atk, "§c[Combat] Bạn đang trong chiến đấu! Thoát game = chết, không dùng được lệnh dịch chuyển.");
            TAG.put(victim.getUuid(), until);
            TAG.put(atk.getUuid(), until);
            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, src) -> {
            if (entity instanceof ServerPlayerEntity p) TAG.remove(p.getUuid());
        });

        // thoat game khi dang bi tag -> chet + rot do
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (tagged(p)) {
                TAG.remove(p.getUuid());
                server.getPlayerManager().broadcast(Text.literal("§c" + p.getName().getString() + " đã thoát game khi đang chiến đấu và bị xử tử!"), false);
                p.kill((ServerWorld) p.getWorld());
            }
            TAG.remove(p.getUuid());
        });
    }

    static void everySecond(MinecraftServer s) {
        if (!Admin.on("combat")) return;
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            Long t = TAG.get(p.getUuid());
            if (t == null) continue;
            if (DonutLike.tick >= t) {
                TAG.remove(p.getUuid());
                p.sendMessage(Text.literal("§aBạn đã thoát trạng thái chiến đấu."), true);
            } else {
                p.sendMessage(Text.literal("§cCombat: " + ((t - DonutLike.tick + 19) / 20) + "s"), true);
            }
        }
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        for (String n : new String[]{"ct", "combat"}) {
            d.register(literal(n).requires(s -> Admin.on("combat")).executes(c -> {
                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                if (tagged(p)) DonutLike.msg(p, "§cBạn còn " + ((TAG.get(p.getUuid()) - DonutLike.tick + 19) / 20) + " giây trong combat.");
                else DonutLike.msg(p, "§aBạn không trong combat.");
                return 1;
            }));
        }
        d.register(literal("pvp").requires(s -> Admin.on("pvpcmd")).executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            if (tagged(p)) { DonutLike.msg(p, "§cKhông thể đổi PvP khi đang combat."); return 0; }
            boolean off = PVP_OFF.add(p.getUuid());
            if (!off) PVP_OFF.remove(p.getUuid());
            DonutLike.msg(p, off ? "§ePvP: §cTẮT" : "§ePvP: §aBẬT §7(vùng spawn luôn khoá PvP)");
            return 1;
        }));
    }
}
