package com.donutlike;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringNbtReader;

/** Luu / doc ItemStack thanh chuoi SNBT de AH khong mat do khi restart. */
public class ItemIO {
    public static String encode(ItemStack s) {
        try {
            var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
            return ItemStack.CODEC.encodeStart(ops, s).getOrThrow().toString();
        } catch (Exception e) { e.printStackTrace(); return null; }
    }

    public static ItemStack decode(String str) {
        try {
            var ops = DonutLike.SERVER.getRegistryManager().getOps(NbtOps.INSTANCE);
            NbtElement el = StringNbtReader.parse(str);
            return ItemStack.CODEC.parse(ops, el).getOrThrow();
        } catch (Exception e) { e.printStackTrace(); return ItemStack.EMPTY; }
    }
}
