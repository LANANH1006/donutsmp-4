package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Menu admin: /dladmin  -> GUI bat/tat tung tinh nang + chinh so.
 * Cong tac tong (master) tat het = server chay gan nhu vanilla (tien cho server khac / modpack khac).
 * Lenh: /dladmin | list | toggle <key> | set <key> <so> | master | reset
 */
public class Admin {
    /** key -> {ten hien thi, mo ta} (thu tu = thu tu hien trong menu) */
    static final LinkedHashMap<String, String[]> FEATURES = new LinkedHashMap<>();
    /** key -> {ten, mac dinh, buoc, min, max} */
    static final LinkedHashMap<String, double[]> NUMS = new LinkedHashMap<>();
    static final Map<String, String> NUM_NAMES = new HashMap<>();
    static {
        f("ah", "Auction House", "/ah, /ah sell, /ah search");
        f("orders", "Orders", "/orders, /order");
        f("combat", "Combat tag", "/ct, tag khi đánh nhau, chặn tp, thoát = chết");
        f("spawnpvp", "Khoá PvP ở spawn", "Vùng quanh spawn không đánh nhau");
        f("pvpcmd", "Lệnh /pvp", "Bật/tắt PvP cá nhân");
        f("notes", "Tờ séc & vé rank", "/withdraw, /redeem, /rankvoucher");
        f("suicide", "Lệnh /suicide", "Tự sát nhanh");
        f("mobstack", "Gộp quái", "Creeper x100...");
        f("itemclean", "Dọn item rơi", "Xoá item cũ khi quá nhiều");
        f("amethyst", "Amethyst hết hạn", "Đồ Amethyst tự huỷ sau N giờ");
        f("bedlock", "Khoá nổ giường", "Giường ở Nether/End không dùng được");
        f("anchorlock", "Khoá Respawn Anchor", "Anchor ngoài Nether không dùng được");
        f("shop", "Shop & /sellall", "/shop, /sellall, /worth");
        f("sidebar", "Bảng bên phải", "Sidebar tiền/kills/...");
        f("duels", "Duel bot", "/duel");
        f("bases", "Căn cứ rải rác", "Tự sinh căn cứ & /randombase");
        n("combat_seconds", "Giây combat", 15, 5, 1, 120);
        n("spawn_radius", "Bán kính spawn (block)", 48, 8, 0, 512);
        n("max_listings", "Số món /ah tối đa", 5, 1, 1, 54);
        n("max_orders", "Số order tối đa", 5, 1, 1, 54);
        n("max_stack", "Gộp quái tối đa", 100, 10, 2, 1000);
        n("item_cap", "Ngưỡng dọn item", 300, 50, 50, 5000);
        n("amethyst_hours", "Giờ sống Amethyst", 72, 6, 1, 720);
    }
    static void f(String k, String name, String desc) { FEATURES.put(k, new String[]{name, desc}); }
    static void n(String k, String name, double def, double step, double min, double max) {
        NUMS.put(k, new double[]{def, step, min, max}); NUM_NAMES.put(k, name);
    }

    // ===== API cho cac module khac =====
    public static boolean on(String key) {
        if (DonutLike.save.masterOff) return false;
        Boolean b = DonutLike.save.toggles == null ? null : DonutLike.save.toggles.get(key);
        return b == null || b;
    }
    public static double num(String key) {
        Double v = DonutLike.save.nums == null ? null : DonutLike.save.nums.get(key);
        return v != null ? v : NUMS.get(key)[0];
    }
    public static int inum(String key) { return (int) Math.round(num(key)); }

    static void setNum(String key, double v) {
        double[] d = NUMS.get(key);
        v = Math.max(d[2], Math.min(d[3], v));
        if (DonutLike.save.nums == null) DonutLike.save.nums = new HashMap<>();
        DonutLike.save.nums.put(key, v);
        DonutLike.doSave();
    }
    static boolean toggle(String key) {
        if (DonutLike.save.toggles == null) DonutLike.save.toggles = new HashMap<>();
        boolean nv = !(DonutLike.save.toggles.getOrDefault(key, true));
        DonutLike.save.toggles.put(key, nv);
        DonutLike.doSave();
        return nv;
    }

    // ===== lenh =====
    static void register(CommandDispatcher<ServerCommandSource> d) {
        for (String root : new String[]{"dladmin", "dlmenu"}) {
            d.register(literal(root).requires(s -> s.hasPermissionLevel(2))
                .executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; })
                .then(literal("list").executes(c -> {
                    StringBuilder sb = new StringBuilder("§6=== DonutLike ===  Master: " + (DonutLike.save.masterOff ? "§cTẮT" : "§aBẬT") + "\n");
                    for (var e : FEATURES.entrySet()) sb.append(on(e.getKey()) ? "§a✔ " : "§c✘ ").append("§f").append(e.getKey()).append(" §7- ").append(e.getValue()[0]).append("\n");
                    for (String k : NUMS.keySet()) sb.append("§e").append(k).append(" = §f").append(fmtNum(num(k))).append("\n");
                    c.getSource().sendFeedback(() -> Text.literal(sb.toString()), false);
                    return 1;
                }))
                .then(literal("toggle").then(argument("key", StringArgumentType.word())
                    .suggests((c, b) -> { FEATURES.keySet().forEach(b::suggest); return b.buildFuture(); })
                    .executes(c -> {
                        String k = StringArgumentType.getString(c, "key");
                        if (!FEATURES.containsKey(k)) { c.getSource().sendError(Text.literal("Không có tính năng: " + k)); return 0; }
                        boolean v = toggle(k);
                        c.getSource().sendFeedback(() -> Text.literal("§e" + k + ": " + (v ? "§aBẬT" : "§cTẮT")), true);
                        return 1;
                    })))
                .then(literal("set").then(argument("key", StringArgumentType.word())
                    .suggests((c, b) -> { NUMS.keySet().forEach(b::suggest); return b.buildFuture(); })
                    .then(argument("value", DoubleArgumentType.doubleArg()).executes(c -> {
                        String k = StringArgumentType.getString(c, "key");
                        if (!NUMS.containsKey(k)) { c.getSource().sendError(Text.literal("Không có thiết lập: " + k)); return 0; }
                        setNum(k, DoubleArgumentType.getDouble(c, "value"));
                        c.getSource().sendFeedback(() -> Text.literal("§e" + k + " = §f" + fmtNum(num(k))), true);
                        return 1;
                    }))))
                .then(literal("master").executes(c -> {
                    DonutLike.save.masterOff = !DonutLike.save.masterOff;
                    DonutLike.doSave();
                    c.getSource().sendFeedback(() -> Text.literal("§eMod: " + (DonutLike.save.masterOff ? "§cTẮT TOÀN BỘ (vanilla)" : "§aBẬT")), true);
                    return 1;
                }))
                .then(literal("reset").executes(c -> {
                    DonutLike.save.toggles = new HashMap<>(); DonutLike.save.nums = new HashMap<>(); DonutLike.save.masterOff = false;
                    DonutLike.doSave();
                    c.getSource().sendFeedback(() -> Text.literal("§aĐã reset toàn bộ thiết lập về mặc định."), true);
                    return 1;
                })));
        }
    }

    static String fmtNum(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }

    // ===== GUI =====
    static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54)), Text.literal("DonutLike Admin")));
    }

    static ItemStack icon(net.minecraft.item.Item it, String name, String... lore) {
        ItemStack s = new ItemStack(it);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        List<Text> l = new ArrayList<>();
        for (String x : lore) l.add(Text.literal(x));
        s.set(DataComponentTypes.LORE, new LoreComponent(l));
        return s;
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv;
        final List<String> featKeys = new ArrayList<>(FEATURES.keySet());
        final List<String> numKeys = new ArrayList<>(NUMS.keySet());

        Gui(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv;
            refresh();
        }

        // tinh nang: slot 0..17 (2 hang). Thiet lap so: slot 27..(27+n). Master: 49. Reset: 53.
        void refresh() {
            for (int i = 0; i < 54; i++) inv.setStack(i, icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            for (int i = 0; i < featKeys.size() && i < 27; i++) {
                String k = featKeys.get(i); String[] f = FEATURES.get(k);
                boolean on = DonutLike.save.toggles == null || DonutLike.save.toggles.getOrDefault(k, true);
                inv.setStack(i, icon(on ? Items.LIME_CONCRETE : Items.RED_CONCRETE,
                    (on ? "§a✔ " : "§c✘ ") + "§f" + f[0], "§7" + f[1], "§8key: " + k, "§eClick để " + (on ? "TẮT" : "BẬT")));
            }
            for (int i = 0; i < numKeys.size() && 27 + i < 45; i++) {
                String k = numKeys.get(i); double[] d = NUMS.get(k);
                inv.setStack(27 + i, icon(Items.PAPER, "§e" + NUM_NAMES.get(k) + ": §f" + fmtNum(num(k)),
                    "§7Mặc định: " + fmtNum(d[0]), "§aChuột trái: +" + fmtNum(d[1]) + "  §cChuột phải: -" + fmtNum(d[1]),
                    "§7Shift: x5"));
            }
            inv.setStack(49, icon(DonutLike.save.masterOff ? Items.BARRIER : Items.BEACON,
                "§6Master: " + (DonutLike.save.masterOff ? "§cTẮT (vanilla)" : "§aBẬT"),
                "§7Tắt = mod ngừng hoạt động hoàn toàn", "§eClick để đổi"));
            inv.setStack(53, icon(Items.TNT, "§cReset mặc định", "§7Click để reset mọi thiết lập"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 54 && player instanceof ServerPlayerEntity sp && sp.hasPermissionLevel(2)
                    && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE)) {
                if (slot < featKeys.size() && slot < 27) toggle(featKeys.get(slot));
                else if (slot >= 27 && slot - 27 < numKeys.size() && slot < 45) {
                    String k = numKeys.get(slot - 27);
                    double step = NUMS.get(k)[1] * (type == SlotActionType.QUICK_MOVE ? 5 : 1);
                    setNum(k, num(k) + (button == 1 ? -step : step));
                } else if (slot == 49) { DonutLike.save.masterOff = !DonutLike.save.masterOff; DonutLike.doSave(); }
                else if (slot == 53) {
                    DonutLike.save.toggles = new HashMap<>(); DonutLike.save.nums = new HashMap<>(); DonutLike.save.masterOff = false;
                    DonutLike.doSave();
                }
                refresh();
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
