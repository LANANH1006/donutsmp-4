package com.donutlike;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ShopHandler extends GenericContainerScreenHandler {
    private final List<Item> items = new ArrayList<>();

    public static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, player) -> new ShopHandler(syncId, inv, new SimpleInventory(27)),
            Text.literal("Shop (click = 1, shift+click = 16)")));
    }

    public ShopHandler(int syncId, PlayerInventory pinv, SimpleInventory inv) {
        super(ScreenHandlerType.GENERIC_9X3, syncId, pinv, inv, 3);
        int i = 0;
        for (String id : DonutLike.PRICES.keySet()) {
            if (i >= 27) break;
            Item it = Registries.ITEM.get(Identifier.of("minecraft", id));
            items.add(it);
            ItemStack d = new ItemStack(it);
            d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("§eGiá: $" + DonutLike.fmt(DonutLike.value(it) * 1.5) + "/cái"))));
            inv.setStack(i++, d);
        }
    }

    @Override
    public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
        if (slot >= 0 && slot < items.size() && player instanceof ServerPlayerEntity sp
                && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE)) {
            Item it = items.get(slot);
            int n = Math.min(type == SlotActionType.QUICK_MOVE ? 16 : 1, it.getMaxCount());
            double cost = DonutLike.value(it) * 1.5 * n;
            if (DonutLike.bal(sp.getUuid()) < cost) {
                DonutLike.msg(sp, "§cKhông đủ tiền ($" + DonutLike.fmt(cost) + ").");
            } else {
                DonutLike.add(sp.getUuid(), -cost);
                sp.getInventory().offerOrDrop(new ItemStack(it, n));
                DonutLike.msg(sp, "§aĐã mua " + n + "x " + new ItemStack(it).getName().getString() + " - $" + DonutLike.fmt(cost));
            }
        }
        syncState();
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
}
